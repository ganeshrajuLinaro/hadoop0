Nutch README

Interesting files include:


  docs/api/index.html
      Javadocs for the Nutch software.

  CHANGES.txt
      Log of changes to Nutch.


For the latest information about Nutch, please visit our website at:

   http://lucene.apache.org/nutch/

and our wiki, at:

   http://wiki.apache.org/nutch/

To get started using Nutch read Tutorial:

   http://lucene.apache.org/nutch/tutorial.html

